namespace RTLTMPro
{
    /// <summary>
    /// Special characters used in Arabis / Persian / Hebrew
    /// </summary>
    public enum SpecialCharacters
    {   
        ZeroWidthNoJoiner = 0x200C,
    }
}