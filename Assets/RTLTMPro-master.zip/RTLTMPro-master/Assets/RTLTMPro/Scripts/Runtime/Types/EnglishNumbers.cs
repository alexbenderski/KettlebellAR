﻿namespace RTLTMPro
{
    public enum EnglishNumbers
    {
        Zero = 0x0030,
        One = 0x0031,
        Two = 0x0032,
        Three = 0x0033,
        Four = 0x0034,
        Five = 0x0035,
        Six = 0x0036,
        Seven = 0x0037,
        Eight = 0x0038,
        Nine = 0x0039
    }
}