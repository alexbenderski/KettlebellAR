# Changelog
These are the release notes for the RTLTMPro package. 

The github repository is: https://github.com/hk1ll3r/RTLTMPro
The parent repository is: https://github.com/mnarimani/RTLTMPro

# v3.4.2 (2021/11/05)
- Support for unicode32 characters (emojis, etc.)
- Fix 3D text

# v3.4.1 (2021/10/15)
- Hebrew support 

# v3.3.9 (2021/05/26)
- Initial release.
